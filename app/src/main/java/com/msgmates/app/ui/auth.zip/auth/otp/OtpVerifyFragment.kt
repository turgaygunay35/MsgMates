package com.msgmates.app.ui.auth.otp

import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.msgmates.app.databinding.FragmentOtpVerifyBinding
import com.msgmates.app.ui.auth.OtpEffect
import com.msgmates.app.ui.auth.OtpEvent
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class OtpVerifyFragment : Fragment() {

    private var _binding: FragmentOtpVerifyBinding? = null
    private val binding get() = _binding!!

    private val viewModel: OtpVerifyViewModel by viewModels()
    private val args: OtpVerifyFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentOtpVerifyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeViewModel()
        initializeViewModel()
    }

    private fun setupUI() {
        // OTP input setup
        binding.etOtp.inputType = InputType.TYPE_CLASS_NUMBER
        binding.etOtp.filters = arrayOf(InputFilter.LengthFilter(6))
        binding.etOtp.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                viewModel.onEvent(OtpEvent.CodeChanged(s?.toString() ?: ""))
            }
        })

        // Submit button
        binding.btnVerify.setOnClickListener {
            viewModel.onEvent(OtpEvent.Submit)
        }

        // Resend button
        binding.btnResend.setOnClickListener {
            viewModel.onEvent(OtpEvent.Resend)
        }
    }

    private fun initializeViewModel() {
        viewModel.initialize(args.phoneNumber)
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                updateUI(state)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiEffect.collect { effect ->
                handleEffect(effect)
            }
        }
    }

    private fun updateUI(state: com.msgmates.app.ui.auth.OtpState) {
        // Update masked phone display
        val maskedPhone = maskPhoneNumber(state.phone)
        binding.tvMaskedPhone.text = maskedPhone

        // Update OTP input
        binding.etOtp.setText(state.code)

        // Update submit button
        binding.btnVerify.isEnabled = state.code.length == 6 && !state.isLoading
        binding.btnVerify.text = if (state.isLoading) "Doğrulanıyor..." else "Doğrula"

        // Update resend button
        binding.btnResend.isEnabled = state.resendEnabled && !state.isLoading
        if (state.resendEnabled) {
            binding.btnResend.text = "Kodu yeniden gönder"
            binding.tvTimer.visibility = View.GONE
        } else {
            binding.btnResend.text = "Kodu yeniden gönder"
            binding.tvTimer.text = "Kodu yeniden gönder (${state.secondsLeft}s)"
            binding.tvTimer.visibility = View.VISIBLE
        }

        // Show/hide progress
        binding.progressOtp.visibility = if (state.isLoading) View.VISIBLE else View.GONE

        // Show error
        if (state.error != null) {
            binding.tilOtp.error = state.error
        } else {
            binding.tilOtp.error = null
        }
    }

    private fun handleEffect(effect: OtpEffect) {
        when (effect) {
            is OtpEffect.NavigateToMain -> {
                // Navigate to main screen and clear auth stack
                val action = OtpVerifyFragmentDirections.actionOtpVerifyToMain()
                findNavController().navigate(action)
            }
        }
    }

    private fun maskPhoneNumber(phone: String): String {
        // Convert +905551234567 to +90 XXX XXX XX XX
        return if (phone.startsWith("+90") && phone.length >= 13) {
            val number = phone.substring(3)
            "+90 ${number.substring(0, 3)} ${number.substring(3, 6)} ${number.substring(6, 8)} ${number.substring(8)}"
        } else {
            phone
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
