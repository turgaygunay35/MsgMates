package com.msgmates.app.ui.auth.otp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.msgmates.app.core.datastore.AuthTokenStore
import com.msgmates.app.data.repository.AuthRepository
import com.msgmates.app.ui.auth.OtpEffect
import com.msgmates.app.ui.auth.OtpEvent
import com.msgmates.app.ui.auth.OtpState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject

@HiltViewModel
class OtpVerifyViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val authTokenStore: AuthTokenStore
) : ViewModel() {

    private val _uiState = MutableStateFlow(OtpState(phone = ""))
    val uiState: StateFlow<OtpState> = _uiState.asStateFlow()

    private val _uiEffect = Channel<OtpEffect>()
    val uiEffect = _uiEffect.receiveAsFlow()

    private var countdownJob: Job? = null

    fun initialize(phone: String) {
        _uiState.value = _uiState.value.copy(phone = phone)
        startCountdown()
    }

    fun onEvent(event: OtpEvent) {
        when (event) {
            is OtpEvent.CodeChanged -> handleCodeChanged(event.value)
            is OtpEvent.Submit -> handleSubmit()
            is OtpEvent.Resend -> handleResend()
        }
    }

    private fun handleCodeChanged(value: String) {
        val cleanCode = value.replace(Regex("[^0-9]"), "")
        _uiState.value = _uiState.value.copy(
            code = cleanCode,
            error = null
        )
    }

    private fun handleSubmit() {
        val currentState = _uiState.value
        if (currentState.code.length != 6) {
            _uiState.value = currentState.copy(
                error = "Lütfen 6 haneli kodu girin."
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = currentState.copy(isLoading = true, error = null)
            
            try {
                val response = authRepository.verifyCode(currentState.phone, currentState.code)
                
                if (response.ok && response.access_token != null) {
                    // Save tokens to DataStore
                    authTokenStore.saveTokens(
                        access = response.access_token,
                        refresh = response.refresh_token ?: "",
                        refreshExp = response.refresh_expires_at
                    )
                    
                    _uiEffect.send(OtpEffect.NavigateToMain)
                } else {
                    _uiState.value = currentState.copy(
                        isLoading = false,
                        error = "Kod doğrulanamadı. Lütfen tekrar deneyin."
                    )
                }
            } catch (e: HttpException) {
                val errorMessage = when (e.code()) {
                    400 -> "Eksik/Geçersiz istek"
                    401 -> "Kod hatalı veya süresi doldu"
                    else -> "Sunucu hatası: ${e.code()}"
                }
                _uiState.value = currentState.copy(
                    isLoading = false,
                    error = errorMessage
                )
            } catch (e: IOException) {
                _uiState.value = currentState.copy(
                    isLoading = false,
                    error = "Sunucuya ulaşılamıyor, lütfen tekrar deneyin"
                )
            } catch (e: Exception) {
                _uiState.value = currentState.copy(
                    isLoading = false,
                    error = "Beklenmeyen bir hata oluştu"
                )
            }
        }
    }

    private fun handleResend() {
        val currentState = _uiState.value
        if (!currentState.resendEnabled) return

        viewModelScope.launch {
            try {
                val response = authRepository.requestCode(currentState.phone)
                
                if (response.ok) {
                    // Reset countdown
                    startCountdown()
                    _uiState.value = currentState.copy(
                        resendEnabled = false,
                        secondsLeft = 45,
                        error = null
                    )
                } else {
                    _uiState.value = currentState.copy(
                        error = "Kod gönderilemedi. Lütfen tekrar deneyin."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = currentState.copy(
                    error = "Kod gönderilemedi. Lütfen tekrar deneyin."
                )
            }
        }
    }

    private fun startCountdown() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            for (seconds in 45 downTo 0) {
                _uiState.value = _uiState.value.copy(
                    secondsLeft = seconds,
                    resendEnabled = seconds == 0
                )
                if (seconds > 0) {
                    delay(1000)
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        countdownJob?.cancel()
    }
}
