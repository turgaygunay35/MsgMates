package com.msgmates.app.ui.auth.phone

import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.msgmates.app.R
import com.msgmates.app.databinding.FragmentPhoneEntryBinding
import com.msgmates.app.ui.auth.PhoneEffect
import com.msgmates.app.ui.auth.PhoneEvent
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class PhoneEntryFragment : Fragment() {

    private var _binding: FragmentPhoneEntryBinding? = null
    private val binding get() = _binding!!

    private val viewModel: PhoneEntryViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPhoneEntryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        // Phone input setup
        binding.etPhone.addTextChangedListener { text ->
            viewModel.onEvent(PhoneEvent.PhoneChanged(text?.toString() ?: ""))
        }

        // Submit button
        binding.btnSendCode.setOnClickListener {
            viewModel.onEvent(PhoneEvent.Submit)
        }

        // Legal text with clickable spans
        setupLegalText()
    }

    private fun setupLegalText() {
        val fullText = getString(R.string.phone_entry_legal_text)
        val spannableString = SpannableString(fullText)
        
        // Make "KVKK" clickable
        val kvkkStart = fullText.indexOf("KVKK")
        val kvkkEnd = kvkkStart + "KVKK".length
        if (kvkkStart != -1) {
            spannableString.setSpan(
                object : ClickableSpan() {
                    override fun onClick(widget: View) {
                        // TODO: Navigate to KVKK page
                        Toast.makeText(context, "KVKK sayfasına yönlendiriliyor", Toast.LENGTH_SHORT).show()
                    }
                },
                kvkkStart,
                kvkkEnd,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        // Make "Kullanım Şartları" clickable
        val tosStart = fullText.indexOf("Kullanım Şartları")
        val tosEnd = tosStart + "Kullanım Şartları".length
        if (tosStart != -1) {
            spannableString.setSpan(
                object : ClickableSpan() {
                    override fun onClick(widget: View) {
                        // TODO: Navigate to Terms of Service page
                        Toast.makeText(context, "Kullanım Şartları sayfasına yönlendiriliyor", Toast.LENGTH_SHORT).show()
                    }
                },
                tosStart,
                tosEnd,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        binding.tvLegal.text = spannableString
        binding.tvLegal.movementMethod = LinkMovementMethod.getInstance()
    }

    private fun observeViewModel() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                updateUI(state)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiEffect.collect { effect ->
                handleEffect(effect)
            }
        }
    }

    private fun updateUI(state: com.msgmates.app.ui.auth.PhoneState) {
        // Update button state
        binding.btnSendCode.isEnabled = state.isValid && !state.isLoading
        binding.btnSendCode.text = if (state.isLoading) "Gönderiliyor..." else "Kod Gönder"

        // Show/hide progress
        binding.progressPhone.visibility = if (state.isLoading) View.VISIBLE else View.GONE

        // Show error
        if (state.error != null) {
            binding.tilPhone.error = state.error
        } else {
            binding.tilPhone.error = null
        }
    }

    private fun handleEffect(effect: PhoneEffect) {
        when (effect) {
            is PhoneEffect.NavigateToOtp -> {
                val action = PhoneEntryFragmentDirections.actionPhoneEntryToOtpVerify(effect.phone)
                findNavController().navigate(action)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
