package com.msgmates.app.ui.auth.phone

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.msgmates.app.data.repository.auth.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class PhoneEntryState(
    val phone: String = "",
    val loading: Boolean = false,
    val error: String? = null,
    val isValid: Boolean = false
)

sealed class PhoneEntryEffect {
    data class NavigateToOtp(val transactionId: String, val identifier: String): PhoneEntryEffect()
    data class ShowError(val message: String): PhoneEntryEffect()
}

@HiltViewModel
class PhoneEntryViewModel @Inject constructor(
    private val repo: AuthRepository
) : ViewModel() {

    private val _state = MutableStateFlow(PhoneEntryState())
    val state: StateFlow<PhoneEntryState> = _state.asStateFlow()

    private val _effect = Channel<PhoneEntryEffect>(Channel.BUFFERED)
    val effect: Flow<PhoneEntryEffect> = _effect.receiveAsFlow()

    fun onPhoneChanged(input: String) {
        val cleaned = input.filter { it.isDigit() }
        _state.update { it.copy(phone = cleaned, isValid = cleaned.length >= 10, error = null) }
    }

    fun onSubmit() = viewModelScope.launch {
        val phone = state.value.phone
        if (!state.value.isValid) {
            _effect.send(PhoneEntryEffect.ShowError("Geçerli bir telefon giriniz"))
            return@launch
        }
        _state.update { it.copy(loading = true, error = null) }
        val res = repo.requestCode(phone)
        res.onSuccess { resp ->
            _state.update { it.copy(loading = false) }
            _effect.send(PhoneEntryEffect.NavigateToOtp(resp.transactionId, resp.identifier))
        }.onFailure { e ->
            _state.update { it.copy(loading = false, error = e.message ?: "İstek başarısız") }
            _effect.send(PhoneEntryEffect.ShowError("OTP gönderilemedi"))
        }
    }
}
